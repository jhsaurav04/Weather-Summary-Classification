Weather Summary Classification — Submission Package
=====================================================
Files:
1. weather_classification.ipynb  → Full Jupyter Notebook (EDA + Preprocessing + Models)
2. Weather_Classification_Report.docx → Final Report

Instructions to run the notebook:
- Place 'weatherHistory.csv' in the same directory as the notebook
- Install requirements: pip install pandas numpy scikit-learn imbalanced-learn plotly matplotlib
- Run all cells in order (Kernel > Restart & Run All)
